import asyncio
import random

import flet as ft
import flet.canvas as cv

BLOCK_SIZE = 20
CANVAS_SIZE = 30


def generate_apple(snake):
    while True:
        x, y = random.randint(0, CANVAS_SIZE - 1), random.randint(0, CANVAS_SIZE - 1)
        if (x, y) not in snake:
            return x, y


async def main(page: ft.Page):
    canvas = cv.Canvas(
        width=CANVAS_SIZE * BLOCK_SIZE,
        height=CANVAS_SIZE * BLOCK_SIZE
    )

    page.add(
        ft.Row(
            [canvas],
            alignment=ft.MainAxisAlignment.CENTER,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            expand=True
        )
    )

    print('BEFORE')

    snake = [(0, 0)]
    direction = 1, 0
    apple = generate_apple(snake)

    print('AFTER')


    def on_keyboard_event(e: ft.KeyboardEvent):
        nonlocal direction

        if e.key == 'Arrow Down':
            new_direction = 0, 1
        elif e.key == 'Arrow Up':
            new_direction = 0, -1
        elif e.key == 'Arrow Left':
            new_direction = -1, 0
        elif e.key == 'Arrow Right':
            new_direction = 1, 0
        else:
            return

        x, y = new_direction
        if (-x, -y) == direction:
            return
        direction = new_direction


    page.on_keyboard_event = on_keyboard_event

    print('GO!')

    while True:
        blocks = [
            [ft.Colors.WHITE] * CANVAS_SIZE
            for _ in range(CANVAS_SIZE)
        ]

        x, y = snake[-1]
        dx, dy = direction
        snake.append(((x + dx) % CANVAS_SIZE, (y + dy) % CANVAS_SIZE))

        if apple in snake:
            apple = generate_apple(snake)
        else:
            snake.pop(0)

        if snake[-1] in snake[:-1]:
            print('GG')
            snake = [(0, 0)]
            direction = 1, 0
            apple = generate_apple(snake)

        blocks[apple[0]][apple[1]] = ft.Colors.RED

        for x, y in snake:
            blocks[x][y] = ft.Colors.GREEN

        canvas.shapes = [
            cv.Rect(
                x * BLOCK_SIZE, y * BLOCK_SIZE,
                BLOCK_SIZE, BLOCK_SIZE,
                paint=ft.Paint(style=ft.PaintingStyle.FILL, color=blocks[x][y])
            )
            for x in range(CANVAS_SIZE)
            for y in range(CANVAS_SIZE)
        ]
        page.update()

        await asyncio.sleep(1 / 10)


ft.app(main)
