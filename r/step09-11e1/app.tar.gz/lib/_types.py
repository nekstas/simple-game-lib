Color = str
Key = str
StepResult = bool
Board = list[list[Color]]
