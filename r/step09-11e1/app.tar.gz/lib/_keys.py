import lib._types as _types

KEY_UP: _types.Key = 'Arrow Up'
KEY_DOWN: _types.Key = 'Arrow Down'
KEY_LEFT: _types.Key = 'Arrow Left'
KEY_RIGHT: _types.Key = 'Arrow Right'

KEY_W: _types.Key = 'W'
KEY_A: _types.Key = 'A'
KEY_S: _types.Key = 'S'
KEY_D: _types.Key = 'D'
