import lib._types as _types

GAME_CONTINUE: _types.StepResult = True
GAME_OVER: _types.StepResult = False
