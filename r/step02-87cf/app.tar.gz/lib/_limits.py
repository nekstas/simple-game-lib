class Board:
    MAX_WIDTH = 60
    MAX_HEIGHT = 50

    MAX_PIXELS_WIDTH = 640
    MAX_PIXELS_HEIGHT = 480


class InfoText:
    MAX_LENGTH = 40


class Title:
    MAX_LENGTH = 50


MAX_STEPS_PER_SECOND = 60
